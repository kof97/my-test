phpcs --standard=PSR2 --extensions=php ..
